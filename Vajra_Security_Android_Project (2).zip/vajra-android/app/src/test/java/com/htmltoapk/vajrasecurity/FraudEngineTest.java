package com.htmltoapk.vajrasecurity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class FraudEngineTest {
    @Test public void realOtpIsSafe() {
        FraudEngine.Result r = FraudEngine.analyze("123456 is your OTP for login. Do not share it with anyone. -HDFC Bank");
        assertEquals("safe", r.level);
        assertFalse(FraudEngine.shouldAlert(r));
    }
    @Test public void kycScamIsDanger() {
        FraudEngine.Result r = FraudEngine.analyze("Your SBI account will be blocked today. Update KYC now http://sbi-kyc-update.xyz/login");
        assertEquals("danger", r.level);
        assertTrue(FraudEngine.shouldAlert(r));
    }
    @Test public void normalChatIsSafe() {
        assertFalse(FraudEngine.shouldAlert(FraudEngine.analyze("Lunch at 2pm?")));
    }
}
