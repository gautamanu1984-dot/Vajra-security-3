package com.htmltoapk.vajrasecurity;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Reads notifications from other apps (only after the user turns on Notification Access),
 * runs the on-device FraudEngine and raises a warning when something looks like a scam.
 * Message text is never stored in full or sent anywhere.
 */
public class VajraListenerService extends NotificationListenerService {
    static final String CHANNEL = "vajra_alerts";
    private static final int MAX_SEEN = 100;

    private final Map<String, Long> seen = new LinkedHashMap<String, Long>() {
        @Override
        protected boolean removeEldestEntry(Entry<String, Long> e) {
            return size() > MAX_SEEN;
        }
    };

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Throwable ignored) {
            // A listener must never crash.
        }
    }

    private void handle(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals(getPackageName())) return;
        Notification n = sbn.getNotification();
        if ((n.flags & (Notification.FLAG_ONGOING_EVENT | Notification.FLAG_GROUP_SUMMARY)) != 0) return;

        Bundle x = n.extras;
        if (x == null) return;
        StringBuilder sb = new StringBuilder();
        append(sb, x.getCharSequence(Notification.EXTRA_TITLE));
        append(sb, x.getCharSequence(Notification.EXTRA_TEXT));
        append(sb, x.getCharSequence(Notification.EXTRA_BIG_TEXT));
        CharSequence[] lines = x.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null) for (CharSequence l : lines) append(sb, l);
        String text = sb.toString().trim();
        if (text.length() < 8) return;
        if (text.length() > 2000) text = text.substring(0, 2000);

        String key = pkg + "|" + text.hashCode();
        long now = System.currentTimeMillis();
        synchronized (seen) {
            Long prev = seen.get(key);
            if (prev != null && now - prev < 10 * 60 * 1000L) return;
            seen.put(key, now);
        }

        FraudEngine.Result r = FraudEngine.analyze(text);
        if (!FraudEngine.shouldAlert(r)) return;

        String app = appLabel(pkg);
        String preview = text.length() > 80 ? text.substring(0, 80) + "…" : text;
        AlertStore.add(this, pkg, app, r, preview);
        notifyUser(app, r);
    }

    private static void append(StringBuilder sb, CharSequence cs) {
        if (cs == null || cs.length() == 0) return;
        if (sb.length() > 0) sb.append('\n');
        sb.append(cs);
    }

    private String appLabel(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    private void notifyUser(String app, FraudEngine.Result r) {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, getString(R.string.channel_alerts),
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription(getString(R.string.channel_alerts_desc));
        nm.createNotificationChannel(ch);

        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean danger = "danger".equals(r.level);
        String title = (danger ? "⚠ Scam warning" : "Suspicious message") + " — " + app;
        String why = r.reasons.isEmpty() ? "Looks risky" : r.reasons.get(0);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(why + " (risk " + r.score + "%)")
                .setStyle(new Notification.BigTextStyle().bigText(why + "\nRisk score " + r.score + "%. Do not click links or share OTP / PIN."))
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
